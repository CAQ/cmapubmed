中华医学会杂志社PubMed文献检索与格式化工具

版本：v1.0f 离线版 20140112

作者：@Starzh，@CAQ9

意见反馈：caq@caq9.info

离线版使用说明：将压缩文件解压后，用浏览器打开cmapubmed.html即可使用。建议使用Firefox或Google Chrome浏览器（搜狗浏览器高速模式）。

